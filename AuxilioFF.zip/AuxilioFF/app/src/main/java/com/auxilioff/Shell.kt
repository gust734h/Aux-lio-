package com.auxilioff

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

object Shell {
    fun running(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = try {
        running() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun request() { try { Shizuku.requestPermission(100) } catch (_: Throwable) {} }

    /** Executa um comando shell com privilégios do Shizuku (nível ADB). */
    fun run(cmd: String): String {
        if (!granted()) return "Shizuku sem permissão"
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            p.waitFor()
            (out + err).trim().ifEmpty { "OK" }
        } catch (e: Throwable) { "Erro: ${e.message}" }
    }
}
