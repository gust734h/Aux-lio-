# Auxílio FF

Painel de otimização do sistema (Poco F7 / HyperOS). Não mexe no jogo nem na mira.

## Compilar
1. Instale o Android Studio e abra a pasta AuxilioFF.
2. Aguarde o Gradle sincronizar e clique em Build > Build APK(s) (use a variante release).
3. O APK sai em app/build/outputs/apk/release/.

## Usar
1. Instale o app Shizuku (Play Store ou GitHub).
2. Ative Opções do desenvolvedor > Depuração sem fio e inicie o Shizuku por "Pareamento sem fio".
3. Abra o Auxílio FF, toque em "Conceder permissão Shizuku".
4. Marque os apps para hibernar, ative as otimizações ou use o MODO JOGO.
5. "Restaurar tudo" desfaz as alterações.
